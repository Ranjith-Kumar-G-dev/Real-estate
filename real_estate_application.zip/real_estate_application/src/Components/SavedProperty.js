import React, { useEffect, useState } from "react";
import Navbar from "./Navbar";
import axios from "axios";

function SavedProperty() {
  const [dataApi, setDataApi] = useState([]);
  const [mail, setMail] = useState("");
  const [id, setId] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const res = await axios.get("http://localhost:3030/saved");
    setDataApi(res.data);
  };
  function onDelete(e) {
    axios.delete(`http://localhost:3030/saved/${e}`);
  }
  function contact(e, i) {
    setMail(e);
    setId(i)
    
  }

  return (
    <div>
      <Navbar />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "20% 20% 20% 20%",
          justifyContent: "space-evenly",
          marginTop: "60px",
        }}
      >
        {dataApi.map((value, i, a) => {
          return (
            <form
              style={{
                height: "47vh",
                overflow: "hidden",
                width: "100%",
                border: "1px solid black",
                margin: "30px 0px",
                backgroundColor: "RGB(240, 255, 244, 0.5)",
              }}
              key={i}
            >
              <div style={{ padding: "0px 0px 0px 0px" }}>
                <img
                  style={{ width: "100%", height: "160px" }}
                  src={a[i].Image}
                  alt="imgsrc"
                ></img>
                <h6
                  style={{
                    margin: "10px",
                    textAlign: "center",
                    fontWeight: "800",
                    color: "RGB(0,0,0, 0.8)",
                  }}
                >
                  Type : {a[i].type} <br />
                  City : {a[i].address.city} <br />
                  State : {a[i].address.state} <br />
                  PinCode : {a[i].address.postalnumber} <br/>
                  {id === value?.id && mail}
                </h6>
              </div>
              <button
                className="btn btn-danger"
                style={{
                  margin: "10px 0 0 15%",
                }}
                onClick={() => {
                  onDelete(value.id);
                }}
              >
                Remove
              </button>
              <button
                type="button"
                className="btn btn-warning"
                style={{
                  margin: "10px 0 0 44px",
                }}
                onClick={() => {
                  contact(value.contact, value.id);
                }}
              >
                Contact
              </button>
            </form>
          );
        })}
      </div>
    </div>
  );
}

export default SavedProperty;
